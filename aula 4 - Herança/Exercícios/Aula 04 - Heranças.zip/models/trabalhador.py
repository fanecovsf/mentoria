class Trabalhador:
    nome:str
    idade:int

    def __init__(self, nome:str, idade:int):
        self.nome = nome
        self.idade = idade

    
    def tempo_para_aposentar(self):
        return 60 - self.idade
    
