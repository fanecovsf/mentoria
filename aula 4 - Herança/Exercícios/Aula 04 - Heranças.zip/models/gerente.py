from models.trabalhador import Trabalhador

class Gerente(Trabalhador):
    plr:float

    def __init__(self, nome: str, idade: int, plr: float):
        super().__init__(nome, idade)
        self.plr = plr