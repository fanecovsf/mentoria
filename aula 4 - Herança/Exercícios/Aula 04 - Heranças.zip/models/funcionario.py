from models.trabalhador import Trabalhador

class Funcionario(Trabalhador):
    va:float

    def __init__(self, nome: str, idade: int, va: float):
        super().__init__(nome, idade)
        self.va = va