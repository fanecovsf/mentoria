class Util:

    @staticmethod
    def maior_valor(valor1: float, valor2: float):
        if valor1 > valor2:
            return valor1
        else:
            return valor2
        
