from models.trabalhador import Trabalhador

from models.gerente import Gerente
from models.funcionario import Funcionario

from utils.util import Util


g1 = Gerente('Henrique', 30, 3000.00)

tempo1 = g1.tempo_para_aposentar()

f1 = Funcionario('João', 23, 500.00)

tempo2 = f1.tempo_para_aposentar()

print(Util.maior_valor(tempo1, tempo2))
