class Util:
    def largerArea(x, y):
        if x > y:
            return 'Larger area: X'
        else:
            return 'Larger area: Y'
